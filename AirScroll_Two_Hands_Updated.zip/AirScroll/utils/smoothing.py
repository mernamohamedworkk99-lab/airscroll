"""Small exponential smoother used to reduce webcam landmark jitter."""

class ExponentialSmoother:
    def __init__(self, alpha=0.35):
        self.alpha = float(alpha)
        self.value = None

    def reset(self):
        self.value = None

    def update(self, new_value):
        new_value = float(new_value)
        if self.value is None:
            self.value = new_value
        else:
            self.value = self.alpha * new_value + (1.0 - self.alpha) * self.value
        return self.value
