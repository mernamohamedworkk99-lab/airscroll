@echo off
if not exist venv\Scripts\python.exe (
  echo Virtual environment not found. Run setup_windows.bat first.
  pause
  exit /b 1
)
venv\Scripts\python.exe test_setup.py
pause
