import unittest
from utils.smoothing import ExponentialSmoother

class TestExponentialSmoother(unittest.TestCase):
    def test_first_value_is_returned(self):
        smoother = ExponentialSmoother(alpha=0.5)
        self.assertEqual(smoother.update(10), 10)

    def test_values_are_smoothed(self):
        smoother = ExponentialSmoother(alpha=0.5)
        smoother.update(0)
        self.assertEqual(smoother.update(10), 5)

    def test_reset(self):
        smoother = ExponentialSmoother()
        smoother.update(10)
        smoother.reset()
        self.assertEqual(smoother.update(4), 4)

if __name__ == "__main__":
    unittest.main()
