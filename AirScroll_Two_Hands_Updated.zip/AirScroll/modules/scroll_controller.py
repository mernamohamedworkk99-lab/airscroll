"""Safe wrapper around PyAutoGUI scrolling."""
import pyautogui

class ScrollController:
    def __init__(self):
        # Move the mouse to the top-left corner to trigger PyAutoGUI's failsafe.
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.015

    def scroll(self, amount):
        amount = int(amount)
        if amount:
            pyautogui.scroll(amount)
