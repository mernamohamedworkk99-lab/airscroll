"""Webcam + MediaPipe gesture recognition for AirScroll."""
import math
import time
import cv2
import mediapipe as mp

from config import (
    CAMERA_INDEX, CAMERA_WIDTH, CAMERA_HEIGHT, CAMERA_FPS,
    PINCH_THRESHOLD, HAND_DEADZONE, HAND_SCROLL_GAIN, MAX_SCROLL_STEP,
    BLINK_EAR_THRESHOLD, MIN_BLINK_SECONDS, MAX_BLINK_SECONDS,
    DOUBLE_BLINK_WINDOW, BLINK_SCROLL_AMOUNT
)
from modules.scroll_controller import ScrollController
from utils.smoothing import ExponentialSmoother


def _distance(a, b):
    return math.hypot(a.x - b.x, a.y - b.y)


def _eye_aspect_ratio(landmarks, indices):
    """Calculate eye aspect ratio from six Face Mesh landmarks."""
    p1, p2, p3, p4, p5, p6 = [landmarks[i] for i in indices]
    vertical_1 = _distance(p2, p6)
    vertical_2 = _distance(p3, p5)
    horizontal = _distance(p1, p4)
    if horizontal <= 1e-6:
        return 0.0
    return (vertical_1 + vertical_2) / (2.0 * horizontal)


class VisionController:
    LEFT_EYE = (33, 160, 158, 133, 153, 144)
    RIGHT_EYE = (362, 385, 387, 263, 373, 380)

    def __init__(self, mode_getter, status_callback):
        self.mode_getter = mode_getter
        self.status_callback = status_callback
        self.scroll = ScrollController()
        self.running = False
        self.cap = None

        self.mp_hands = mp.solutions.hands
        self.mp_face = mp.solutions.face_mesh
        self.mp_draw = mp.solutions.drawing_utils
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            model_complexity=0,
            min_detection_confidence=0.60,
            min_tracking_confidence=0.60,
        )
        self.face_mesh = self.mp_face.FaceMesh(
            static_image_mode=False,
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=0.60,
            min_tracking_confidence=0.60,
        )

        self.hand_smoother = ExponentialSmoother(alpha=0.35)
        self.last_hand_y = None
        self.was_pinching = False

        self.eye_closed = False
        self.eye_close_started = None
        self.first_blink_time = None
        self.blink_waiting = False
        self.last_blink_result = "No blink detected"

    def open_camera(self):
        self.cap = cv2.VideoCapture(CAMERA_INDEX, cv2.CAP_DSHOW)
        if not self.cap.isOpened():
            self.cap.release()
            self.cap = cv2.VideoCapture(CAMERA_INDEX)
        if not self.cap.isOpened():
            raise RuntimeError(
                "Could not open webcam. Close other camera apps and check Windows camera permissions."
            )
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAMERA_WIDTH)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAMERA_HEIGHT)
        self.cap.set(cv2.CAP_PROP_FPS, CAMERA_FPS)

    def close(self):
        self.running = False
        if self.cap is not None:
            self.cap.release()
            self.cap = None
        self.hands.close()
        self.face_mesh.close()

    def _reset_hand(self):
        self.hand_smoother.reset()
        self.last_hand_y = None
        self.was_pinching = False

    def _handle_hand(self, results, frame):
        """Track up to two hands; either hand can activate pinch scrolling.

        If both hands are pinching, their vertical midpoint is averaged so
        coordinated two-hand movement produces one stable scroll signal.
        """
        if not results.multi_hand_landmarks:
            self._reset_hand()
            return "Show one or both hands to the camera"

        pinch_positions = []
        detected_count = len(results.multi_hand_landmarks)

        for hand_landmarks in results.multi_hand_landmarks:
            self.mp_draw.draw_landmarks(
                frame, hand_landmarks, self.mp_hands.HAND_CONNECTIONS
            )
            points = hand_landmarks.landmark
            pinch_distance = _distance(points[4], points[8])
            if pinch_distance < PINCH_THRESHOLD:
                midpoint_y = (points[4].y + points[8].y) / 2.0
                pinch_positions.append(midpoint_y)

        if not pinch_positions:
            self._reset_hand()
            if detected_count == 2:
                return "2 hands detected - pinch thumb + index on either hand"
            return "Hand detected - pinch thumb + index finger"

        # Either hand can scroll. If both pinch, average their vertical
        # positions so the two hands create one combined scroll signal.
        target_y = sum(pinch_positions) / len(pinch_positions)
        smooth_y = self.hand_smoother.update(target_y)

        if self.last_hand_y is not None:
            movement = self.last_hand_y - smooth_y
            if abs(movement) > HAND_DEADZONE:
                amount = int(round(movement * HAND_SCROLL_GAIN))
                amount = max(-MAX_SCROLL_STEP, min(MAX_SCROLL_STEP, amount))
                if amount:
                    self.scroll.scroll(amount)

        self.last_hand_y = smooth_y
        self.was_pinching = True

        if len(pinch_positions) == 2:
            return "BOTH HANDS PINCHING - move them together up/down"
        if detected_count == 2:
            return "2 HANDS DETECTED - 1 PINCH ACTIVE"
        return "PINCH ACTIVE - move hand up/down"

    def _handle_blink(self, results, now):
        if not results.multi_face_landmarks:
            self.eye_closed = False
            self.eye_close_started = None
            return "Face not detected - look at the camera"

        landmarks = results.multi_face_landmarks[0].landmark
        left_ear = _eye_aspect_ratio(landmarks, self.LEFT_EYE)
        right_ear = _eye_aspect_ratio(landmarks, self.RIGHT_EYE)
        ear = (left_ear + right_ear) / 2.0
        closed_now = ear < BLINK_EAR_THRESHOLD

        if closed_now and not self.eye_closed:
            self.eye_closed = True
            self.eye_close_started = now

        elif not closed_now and self.eye_closed:
            duration = now - (self.eye_close_started or now)
            self.eye_closed = False
            self.eye_close_started = None

            if MIN_BLINK_SECONDS <= duration <= MAX_BLINK_SECONDS:
                if self.first_blink_time is None:
                    self.first_blink_time = now
                    self.blink_waiting = True
                    self.last_blink_result = "Blink detected - waiting briefly"
                elif now - self.first_blink_time <= DOUBLE_BLINK_WINDOW:
                    self.scroll.scroll(BLINK_SCROLL_AMOUNT)
                    self.first_blink_time = None
                    self.blink_waiting = False
                    self.last_blink_result = "DOUBLE BLINK - scroll up"
                else:
                    # The previous blink is treated as a single blink.
                    self.scroll.scroll(-BLINK_SCROLL_AMOUNT)
                    self.first_blink_time = now
                    self.blink_waiting = True
                    self.last_blink_result = "BLINK - scroll down"

        if self.blink_waiting and self.first_blink_time is not None:
            if now - self.first_blink_time > DOUBLE_BLINK_WINDOW:
                self.scroll.scroll(-BLINK_SCROLL_AMOUNT)
                self.first_blink_time = None
                self.blink_waiting = False
                self.last_blink_result = "BLINK - scroll down"

        return f"EAR: {ear:.3f} | {self.last_blink_result}"

    def process_frame(self, frame):
        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mode = self.mode_getter()

        if mode == "Hand Pinch":
            results = self.hands.process(rgb)
            status = self._handle_hand(results, frame)
            # Keep face blink state clean when switching modes.
            self.eye_closed = False
            self.eye_close_started = None
            self.first_blink_time = None
            self.blink_waiting = False
        else:
            results = self.face_mesh.process(rgb)
            if results.multi_face_landmarks:
                face = results.multi_face_landmarks[0]
                self.mp_draw.draw_landmarks(
                    frame,
                    face,
                    self.mp_face.FACEMESH_CONTOURS,
                    landmark_drawing_spec=None,
                    connection_drawing_spec=self.mp_draw.DrawingSpec(
                        color=(80, 220, 120), thickness=1, circle_radius=1
                    ),
                )
            status = self._handle_blink(results, time.monotonic())
            self._reset_hand()

        cv2.putText(
            frame, f"MODE: {mode.upper()}", (18, 32),
            cv2.FONT_HERSHEY_SIMPLEX, 0.75, (40, 220, 120), 2, cv2.LINE_AA
        )
        return frame, status

    def run(self, frame_callback, stop_event):
        self.running = True
        try:
            self.open_camera()
            self.status_callback("Camera connected")
            while not stop_event.is_set():
                ok, frame = self.cap.read()
                if not ok:
                    self.status_callback("Camera frame could not be read")
                    time.sleep(0.05)
                    continue
                processed, status = self.process_frame(frame)
                frame_callback(processed, status)
        finally:
            self.close()
