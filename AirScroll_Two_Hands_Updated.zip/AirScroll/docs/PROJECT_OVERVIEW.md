# AirScroll — Project Overview

## Problem
Frequent mouse-wheel interaction can be inconvenient when a user's hands are occupied or when touchless interaction is preferred.

## Proposed solution
AirScroll is a webcam-based desktop prototype that maps two intentional visual gestures to scrolling actions.

## Main components
1. Camera capture — OpenCV reads frames from the laptop webcam.
2. Hand tracking — MediaPipe Hands detects up to two hands simultaneously and supplies landmarks for each.
3. Pinch recognition — normalized thumb-index distance is checked independently for each hand. Either hand can scroll; if both pinch, their vertical positions are averaged.
4. Face tracking — MediaPipe Face Mesh supplies facial landmarks.
5. Blink recognition — eye aspect ratio (EAR) estimates whether the eyes are closed.
6. Scroll automation — PyAutoGUI sends scroll events to the active application.
7. Smoothing — an exponential moving average reduces small landmark fluctuations.
8. Desktop interface — CustomTkinter provides mode selection and camera controls.

## Gesture mapping
| Gesture | Action |
|---|---|
| Hold thumb and index finger pinched, move hand upward | Scroll up |
| Hold thumb and index finger pinched, move hand downward | Scroll down |
| One deliberate blink | Scroll down after the double-blink detection window |
| Quick double blink | Scroll up |

## Safety and limitations
This is a prototype, not an accessibility-certified product. Recognition depends on camera placement, lighting, and individual movement. Test in a safe browser page first. Avoid using it during sensitive tasks. PyAutoGUI failsafe is enabled.

## Suggested evaluation
- Test in bright, medium, and dim lighting.
- Record false positive and missed gesture counts.
- Measure perceived scrolling responsiveness.
- Tune thresholds in `config.py` on the target laptop.
