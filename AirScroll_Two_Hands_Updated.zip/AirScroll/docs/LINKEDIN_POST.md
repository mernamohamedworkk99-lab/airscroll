# LinkedIn post draft

🚀 Excited to share **AirScroll — Touchless Screen Control**, a Computer Vision project built with Python!

AirScroll explores a more hands-free way to interact with a computer using only a regular laptop webcam.

✨ **Two interaction modes:**
- **Hand Pinch Mode:** pinch thumb and index on either hand. It tracks two hands simultaneously and combines their movement when both are pinching.
- **Blink Mode:** a deliberate single blink scrolls down, while a quick double blink scrolls up.

🛠️ **Tech stack:**
Python | OpenCV | MediaPipe | PyAutoGUI | NumPy | CustomTkinter

Through this project, I worked with real-time video processing, hand and face landmark detection, gesture recognition, smoothing, and desktop automation.

This is an ongoing prototype, and I’m looking forward to improving its accuracy and user experience.

#Python #ComputerVision #OpenCV #MediaPipe #AI #MachineLearning #HumanComputerInteraction #BuildInPublic
